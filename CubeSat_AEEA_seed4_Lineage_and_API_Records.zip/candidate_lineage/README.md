# CubeSat AEEA candidate lineage logs

This package contains recorded logs from one actual AEEA run on Satellite_WN5, seed 4, population size 50, and 100 generations including initialization. It does not contain 30 independent runs or conditional resampled trajectories.

## Contents and relationships

- individuals.jsonl: candidate ID, creation generation, source, parent IDs, prompt-context IDs, chromosome and chromosome hash.
- lineage_edges.jsonl: from_id, to_id and relation. Preserve relation types when interpreting edges. LLM prompt-context links indicate information exposure, not genetic parentage or proof of causal influence.
- lineage_events.jsonl: candidate events and associated values; event schemas may vary.
- population_membership.jsonl: generation, position, candidate ID, source, elite-retention flag and objective values.
- prompt_contexts.jsonl: elite candidates and objective values supplied as context, and requested candidate count.
- repair_candidates.jsonl: API call linkage ID, feasibility flags, before/after chromosomes, edits, timing and available objectives. An API call ID is an identifier, not an API credential.
- crossover_events.jsonl and mutation_events.jsonl: recorded evolutionary-operator events.
- llm_quota_events.jsonl: recorded LLM candidate-quota events.
- generations.jsonl: generation-level records.
- evaluations.jsonl.gz: gzip-compressed evaluation records.
- instance_snapshot.json: saved numerical instance.
- selected_schedule.json: the final-population minimum-total-cost solution used for the procurement and assembly figure, with matching final candidate IDs, recorded schedule and objective values.
- FILE_MANIFEST.json: per-file byte counts, record counts, SHA-256 hashes and first-record field names.

Use individual_id and the relation-specific IDs to join records. Do not interpret log event counts as independent experimental sample sizes. Candidate IDs can refer to intermediate operator outputs, not only evaluated or surviving individuals. Machine and supplier-option indices in raw records may be zero-based; plotting labels were converted to one-based indices.

## Verification and scope

All selected JSON/JSONL records were parsed. Archive entries were compared byte-for-byte against the source files using SHA-256 and the ZIP CRC was checked. No raw API requests, responses, authorization headers, model credentials or billing records are included. A basic credential-pattern scan was performed; this is not an exhaustive privacy/security audit. Review the contents and institutional sharing permissions before making a repository public.

This package preserves the original selected logs without modifying their data. It does not certify that every lineage relation is complete or scientifically causal. No GitHub upload was performed by this packaging step.
