# CubeSat AEEA seed-4 evidence package

The candidate_lineage folder contains the lineage logs and selected schedule. The api_records folder contains shareable API records and configuration. Fig27_analysis.txt contains the accompanying manuscript paragraph. Source archives remain unchanged. API billing records are not available. This archive has not been uploaded to GitHub by this packaging step. After upload, the manuscript may identify the accompanying GitHub repository as the package location.
