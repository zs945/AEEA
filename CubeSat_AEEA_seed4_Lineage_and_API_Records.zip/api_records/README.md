# CubeSat AEEA seed-4 API records

Scope: one actual Satellite_WN5 run, not the full main-experiment suite.

Access window UTC: 2026-09-18 13:58:15.971250 to 17:14:11.539824.
Access window Asia/Shanghai: 2026-09-18 21:58:15.971250 to 2026-09-19 01:14:11.539824.
Provider endpoint: https://api.deepseek.com
Requested model alias: deepseek-reasoner.
Returned model identifier: deepseek-flash.
System fingerprint: aeb56401ca74e127821c4f9126dcb669.
The returned identifier and fingerprint do not establish a named or dated model-weight version such as DeepSeek V4 Pro.

max_tokens was NOT sent. The historical numeric server default was not recorded and cannot be recovered from this package. temperature, top_p and an LLM random seed were also not sent. response_format was json_object; stream was false. Requests asked for 15 candidates. Per-call requested_candidates and elite_context_size are in the log.

98 logical calls, 100 API attempts including 2 retries. Recorded total input tokens: 1,878,808; completion tokens: 3,846,469; total: 5,725,277. Completion usage includes recorded reasoning tokens. Cache-hit input: 1,228,672; cache-miss input: 650,136. These are logged usage totals, not an invoice or proof of billed usage for failed attempts.

Actual billed amount: unavailable in the saved records. Estimated amount: also unavailable because historical prices were not supplied or verified. estimated_cost_usd null means unknown, not zero. Obtain the provider billing export to report actual charges. Do not substitute present-day prices without explicitly labeling and dating an estimate.

This is a shareable subset: original call fields are retained except prompt_file/raw_output_file paths are reduced to basenames; environment and source-file-path sections are omitted from the configuration. Prompts, raw responses and hidden reasoning text are not included. Review before public publication. No GitHub upload is performed.
