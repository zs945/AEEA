# Complete recorded evolutionary trace for S2

This package supports Section 5.2.4, Illustrative Evolutionary Trace on a Small Instance.
It contains the complete **recorded** history of one online Full AEEA run, not only the
four selected individuals shown in the manuscript. No event or candidate is removed.
Completeness refers to the trace runner's logged fields; it does not imply access to
unlogged LLM internal reasoning. This is a data package, not a standalone solver.

## Experimental provenance

- Source run: S2_seed4_20260916_223934; random seed 4; one independent run.
- Instance: S2 from the exact-solution validation experiment, Section 5.1.5.
- WN1; two orders and three product instances. Order 0: P1 and P2; Order 1: P2.
- Population 50; 100 generations; 10 retained elites; five elite prompt records;
  15 LLM candidates and 25 GA offspring per generation.
- Nominal procurement lead times. The 30 scenario evaluations stored per evaluation
  repeat the nominal setting; they are NOT 30 independent algorithm runs.
- Selection: nondomination rank, then descending normalized crowding distance.
- Metadata retain the original algorithm-source path relative to the workspace and
  its SHA-256. The source directory's `wn4` label is NOT this trace's configuration:
  the trace runner supplied WN1 instance data.

## Files

- data/events.jsonl.gz: complete chronological event stream, including creation,
  evaluation, parent selection, crossover, mutation, validation/repair and selection.
- data/individuals.jsonl.gz: registered individuals, full six-segment chromosomes,
  origin, birth generation, parents, objectives, feasibility and evaluation records.
- data/individuals.csv.gz: tabular export of registered individuals.
- data/lineage_edges.csv.gz: full edge list with parent_id, child_id and relation.
- data/population_membership.csv: generation-by-generation membership, rank,
  crowding distance and costs, including the initial population.
- data/generation_summary.csv: generation-level summary for generations 1–100.
- data/llm_repair_summary.csv.gz: all 1,500 LLM candidate validation records,
  before/after chromosomes, acceptance flags and repair-edit counts.
- data/llm_calls/: 100 supplied prompt files, recorded response files and validation
  files. Response files are exactly the forms stored by the runner; they are not
  asserted to be complete HTTP transport logs or hidden reasoning traces.
- data/final_nondominated_set.csv: final nondominated population entries.
- data/selected_final_lineages.json and data/selected_lineage.svg: original selected
  endpoint ancestor records and their vector visualization, not the complete graph.
- illustration/S2_selected_lineage.svg and selected_lineage_source.csv: simplified
  four-node manuscript illustration and its source values.
- schema.json: actual CSV columns and logged event-type fields.
- audit_summary.json: record counts, integrity checks and export transformations.
- manifest.json: original-source and exported-file checksums.
- SHA256SUMS.txt: checksums for every other file in this package.

## Reading the records

Join files by individual_id; edges use parent_id and child_id. IDs identify records,
not necessarily unique chromosomes. Use fingerprint or the genome to assess duplicate
chromosomes. The final nondominated population contains 22 entries but 14 distinct
chromosomes. Individual-table parent fields and edge relations must be interpreted
together: a prompt-context predecessor is not a genetic parent.

`prompt_context` edges mean the predecessor was included in the supplied prompt.
They do not prove which example caused an LLM output. Crossover/mutation relations
record evolutionary transformations; an operator event can make no chromosome change.
Raw and accepted versions can therefore have distinct IDs but identical chromosomes.
All 1,500 LLM candidates in this run passed validation without repair edits. These
unchanged before/after records are retained; no repaired examples were invented.

Raw objective arrays use **procurement cost, order-delay penalty, inventory cost**.
The manuscript reports **procurement cost, inventory cost, order-delay penalty**.
CSV columns are explicitly named. Costs use the model's monetary unit; no currency
conversion is performed. Total cost is the sum of the three components.
Indices in chromosomes are zero-based. Near-zero floating-point values are preserved
in the data even where the manuscript displays zero. `null` denotes an unavailable
JSON value; an unevaluated intermediate record is not automatically an infeasible one.
Crowding distance may be `inf` for boundary solutions. Embedded JSON fields are stored
inside quoted CSV cells. Some logs may contain Python-style Infinity values, which
Python's JSON reader accepts; no numerical values were changed on export.

To read compressed files using Python's standard library:

```python
import csv, gzip, json
with gzip.open('data/lineage_edges.csv.gz', 'rt', encoding='utf-8') as f:
    edges = list(csv.DictReader(f))
with gzip.open('data/individuals.jsonl.gz', 'rt', encoding='utf-8') as f:
    individuals = {r['individual_id']: r for r in map(json.loads, f)}
```

## Export and publication status

The original local results were left unchanged. Workspace path prefixes were removed
from the public copies. Large CSV/JSONL files were compressed losslessly. All exported
text was checked for common credential patterns; no matching credentials were found.
No environment files or credentials are included. The original results README is
replaced here; its runtime value is not used in this package.

Prepared locally for the author's GitHub upload; NOT uploaded by the assistant.
Before publication, add the actual repository URL, authors, manuscript citation and
an author-approved data licence. No licence or DOI is assumed by this package.
For traceability, cite the uploaded release or commit rather than a moving branch.

Suggested manuscript note AFTER upload:

Note. The complete evolutionary trace for S2, including individual provenance,
prompt-context links, parent–offspring relationships, genetic operations, and
validation and repair records, is available in the GitHub repository at [repository URL].
